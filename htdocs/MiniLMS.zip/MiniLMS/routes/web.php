<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CourseController; 
use App\Http\Controllers\TeacherController; 
use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth; 

// Redirect the root URL: If logged in, go to Dashboard (or Courses); otherwise, go to Login.
Route::get('/', function () {
    if (Auth::check()) {
        // I can redirect to the dashboard or directly to the Course list
        return redirect()->route('dashboard'); 
    }
    return redirect()->route('login');
});

// Protected routes requiring authentication
Route::middleware('auth')->group(function () {
    
    // --- BREEZE DEFAULT ROUTES ---
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->middleware(['auth', 'verified'])->name('dashboard');
    
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    // --- END BREEZE DEFAULT ROUTES ---
    
    // --- MINI-LMS MODULE ROUTES ---
    
    // 3. Course Management (CRUD routes: index, create, store, edit, update, destroy)
    Route::resource('courses', CourseController::class); 
    
    // 4. Teacher/Faculty Management (CRUD routes)
    Route::resource('teachers', TeacherController::class);

    // NEW: Student Management Routes
    Route::resource('students', StudentController::class);

    // --- END MINI-LMS MODULE ROUTES ---

});

require __DIR__.'/auth.php';