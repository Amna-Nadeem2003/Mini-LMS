<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource (READ operation - List all students).
     */
    public function index()
    {
        // Retrieve all students, ordered by the latest created
        $students = Student::latest()->get();
        
        // Return the view and pass the students data to it
        return view('students.index', compact('students'));
    }

    /**
     * Show the form for creating a new resource (CREATE operation - Display form).
     */
    public function create()
    {
        // Return the view containing the form for adding a new student
        return view('students.create');
    }

    /**
     * Store a newly created resource in storage (CREATE operation - Handle submission).
     */
    public function store(Request $request)
    {
        // 1. Validation
        $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|unique:students|max:255',
            'phone_number' => 'nullable|max:20',
            // Roll number must be unique in the students table
            'roll_number' => 'required|unique:students|max:50',
            'academic_program' => 'required|max:100',
        ]);

        // 2. Creation using mass assignment
        Student::create($request->all());

        // 3. Redirect back to the index page with a success message
        return redirect()->route('students.index')->with('success', 'New student added successfully!');
    }

    /**
     * Display the specified resource (READ operation - Single student view).
     */
    public function show(Student $student)
    {
        // We typically skip this view in basic admin modules, 
        // but if needed: return view('students.show', compact('student'));
        return redirect()->route('students.index');
    }

    /**
     * Show the form for editing the specified resource (UPDATE operation - Display form).
     */
    public function edit(Student $student)
    {
        // Logic for future lab (if needed): return view('students.edit', compact('student'));
        return view('students.edit', compact('student'));
    }

    /**
     * Update the specified resource in storage (UPDATE operation - Handle update submission).
     */
    public function update(Request $request, Student $student)
    {
        // Logic for future lab (if needed): 
        $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:students,email,' . $student->id, // Ignores current student ID
            'phone_number' => 'nullable|max:20',
            'roll_number' => 'required|max:50|unique:students,roll_number,' . $student->id,
            'academic_program' => 'required|max:100',
        ]);

        $student->update($request->all());
        return redirect()->route('students.index')->with('success', 'Student updated successfully!');
    }

    /**
     * Remove the specified resource from storage (DELETE operation).
     */
    public function destroy(Student $student)
    {
        // Logic for future lab (if needed):
        $student->delete();
        return redirect()->route('students.index')->with('success', 'Student deleted successfully!');
    }
}